var structxsd____base64_binary =
[
    [ "__ptr", "structxsd____base64_binary.html#a6ba9f9e291b2b26e0696bd48f4e983be", null ],
    [ "__size", "structxsd____base64_binary.html#aa2dfd4d99f8280c413b9ff25a69a8729", null ],
    [ "id", "structxsd____base64_binary.html#a6398e9d86079896facc3005871d7fe27", null ],
    [ "options", "structxsd____base64_binary.html#a16d2bb03d68bf276bad5fd7cccd55bbe", null ],
    [ "type", "structxsd____base64_binary.html#acbc2d7ba24334ccc4f8ec36e9122e9e5", null ]
];