var struct_namespace =
[
    [ "id", "struct_namespace.html#a715d108cd7f9d5a482c1f485368e883d", null ],
    [ "in", "struct_namespace.html#a0cf9dde9e30a474943fd2bdc566e4826", null ],
    [ "ns", "struct_namespace.html#a2e35f8b01b0d81d67dd3f1183f51a8a8", null ],
    [ "out", "struct_namespace.html#a18b3d9994735b97920ba882e3cf72367", null ]
];