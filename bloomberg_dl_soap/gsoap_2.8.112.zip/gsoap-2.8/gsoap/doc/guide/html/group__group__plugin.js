var group__group__plugin =
[
    [ "soap_register_plugin", "group__group__plugin.html#gad645e5a58ed442fe4753dcc2338c8bdb", null ],
    [ "soap_register_plugin_arg", "group__group__plugin.html#ga800a005ce0f0236461d1a5dbf4be2a80", null ]
];