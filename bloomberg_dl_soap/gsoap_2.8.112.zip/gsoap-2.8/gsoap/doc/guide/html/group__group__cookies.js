var group__group__cookies =
[
    [ "soap_cookie", "structsoap__cookie.html", [
      [ "domain", "structsoap__cookie.html#a6b3d69923c76d97c76e7b4c5fec1ee80", null ],
      [ "env", "structsoap__cookie.html#aacd76b0b0d424bb89ee4240c274da227", null ],
      [ "expire", "structsoap__cookie.html#a41b95e8384a5edcdd64df1002a3162b4", null ],
      [ "maxage", "structsoap__cookie.html#ac40390fef80642e034c6b99a8ea71fae", null ],
      [ "modified", "structsoap__cookie.html#abb592791f60cb4b05859daebf1242bf4", null ],
      [ "name", "structsoap__cookie.html#ac8a458d1244b6ee7e7931da3a5782e65", null ],
      [ "next", "structsoap__cookie.html#a7ceb718a0dcbe145640e781cc8ecf7ff", null ],
      [ "path", "structsoap__cookie.html#ab4e90f5b59f0817ab85b6d770c25a5f9", null ],
      [ "secure", "structsoap__cookie.html#a7f43ecd1ff774a39db24d19fa7e5f948", null ],
      [ "session", "structsoap__cookie.html#aceb63cc1437ca17ea950f82d3f395eca", null ],
      [ "value", "structsoap__cookie.html#a3ca9ddd61d9e8b7cc9c93831215e5f09", null ],
      [ "version", "structsoap__cookie.html#a85e58ae9e1c527bd48b27562dfc360a3", null ]
    ] ],
    [ "soap_clr_cookie", "group__group__cookies.html#gac6b00dc725a0e74cf0342070151da94f", null ],
    [ "soap_clr_cookie_session", "group__group__cookies.html#ga760df00c0998efaeaddc39e401f3e168", null ],
    [ "soap_cookie", "group__group__cookies.html#gabbc3a19d40bc8f3c2aed3c719e0569e9", null ],
    [ "soap_cookie_expire", "group__group__cookies.html#gaac3464da4691fe86b2421bafecee0b6d", null ],
    [ "soap_cookie_value", "group__group__cookies.html#ga0dd82c4fd7b499208d2402b195a182fe", null ],
    [ "soap_free_cookies", "group__group__cookies.html#gacf59ec191a3c7012dd6171f7db3d2c6b", null ],
    [ "soap_getenv_cookies", "group__group__cookies.html#ga7e55b641c3a3d6f9710b523e41917fe8", null ],
    [ "soap_set_cookie", "group__group__cookies.html#ga7d5b0588ea763e511772f0cc2498e322", null ],
    [ "soap_set_cookie_expire", "group__group__cookies.html#gae22594f7ccdd5476bcdd93626b3006ef", null ],
    [ "soap_set_cookie_secure", "group__group__cookies.html#gac7ecc82a09c396a50c56ce801662de71", null ],
    [ "soap_set_cookie_session", "group__group__cookies.html#ga5f7d712b3d1c7c2a09741aa45621dfb5", null ]
];